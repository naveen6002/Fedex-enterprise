package com.example.serverapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerappApplicationTests {

	@Test
	void contextLoads() {
	}

}
